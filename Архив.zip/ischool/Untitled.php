<?
class Login extends CI_Controller 
{
	public function index() 
	{
		if(isset($_GET['username']) && isset($_GET['password']))
		{
			$username = $_GET['username'];
			$pass = $_GET['password'];
			
			$getuser = $this->model->get('users','username',$username);
			//print_r($getuser);
			if(isset($getuser[0])){
				$pass2 = $getuser[0]['password'];
				if($pass == $pass2) {
					if($getuser[0]['ban'] == 1)
					{
						$ban = strtotime($getuser[0]['ban_date']);
						$now = strtotime("now");
						if($now >= $ban)
						{
							$new['ban'] = 0;
							$new['ban_info'] = 0;
							$new['ban_admin'] = 0;							
							$new['ban_date'] = 0;		
							$this->model->update('users','username', $username, $new);
							$error = urlencode("Вы успешно разбанены! Для продолжения войдите в систему!");
							redirect(
							"/login?username=".$username."&password=".$pass
							); 
						}
						else
						{
							$adm = $this->model->get("users","user_id",$getuser[0]['ban_admin']);
                            session_start();
                            $_SESSION['first_name']=$getuser[0]['first_name'];
                            $_SESSION['last_name']=$getuser[0]['last_name'];
                            $_SESSION['ban'] = 1;
                            $_SESSION['ban_info'] = $getuser[0]['ban_info'];
                            $_SESSION['ban_date'] = $getuser[0]['ban_date'];
                            $_SESSION['ban_admin'] = $adm[0]['first_name']." ".$adm[0]['last_name'];
                            $_SESSION['ban_email'] = $adm[0]['email'];
                            redirect("/");

						}
					}
					else
					{
                        session_start();
                        $folder = $this->model->homefolder($getuser[0]['kurs'], $getuser[0]['group']);
                        if(!isset($folder[0])) {$folder[0]['folderId'] = 1; $folder[0]['parent']= 0;}
                        $_SESSION['homefolder']=$folder[0]['folderId'];
                        $_SESSION['parent'] = $folder[0]['parent'];

                        $_SESSION['user_id']=$getuser[0]['user_id'];
                        $_SESSION['username']=$getuser[0]['username'];
                        $_SESSION['first_name']=$getuser[0]['first_name'];
                        $_SESSION['last_name']=$getuser[0]['last_name'];
                        $_SESSION['admin']=$getuser[0]['admin'];
                        $_SESSION['anonim']=$getuser[0]['anonim'];
						redirect("/");
					}
				}
				else {
					$error = urlencode("Неверный логин или пароль!");
					redirect(
					"/?error=".$error
					); 
				}
			}
			else{
				$error = urlencode("Неверный логин или пароль!");
				redirect(
				"/?error=".$error
				); 
			}
		}
		else
			redirect("/");
	}
}
?>