

<div class="container">
	<div class="row">
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"></div>
				<div class="panel-body">
					<form method="post" style="margin-bottom: 10px;">
				<select id="class" name="class" onchange="this.form.submit();" >
						<?php
							foreach ($classes as $class) {
								if(isset($class['YEAR_ID'])) $year_border = " (".date("Y",strtotime($class['YEAR_START']))." - ".date("Y",strtotime($class['YEAR_FINISH']))." гг.)"; else $year_border = '';
							?>
									<option value="<?php echo $class['CLASS_ID']?>"><?php echo $class['CLASS_NUMBER']." ".$class['CLASS_LETTER'].$year_border; ?></option>
									<?php
								}
						?>
					</select>
			</form>
			<form method="post">
				<select id="subject" name="subject" onchange="this.form.submit();">
						<?php
							foreach ($subjects as $subject) {
									?>
									<option value="<?php echo $subject['SUBJECTS_CLASS_ID']?>"><?php echo $subject['SUBJECT_NAME']; ?></option>
									<?php
								}
						?>
					</select>
	</form>
		        </div>
	        </div>
		</div>
	    <div class="col-md-8">
			<div class="panel panel-default">
		<div class="panel-heading">Статистика</div>
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Период</th>
						<th>На "5"</th>
						<th>На "4"</th>
						<th>На "3"</th>
						<th>На "2"</th>
						<th>Усп. %</th>
						<th>Кач. %</th>
				   </tr>
				</thead>
				<tbody>
					<?php if(isset($stat)) {
							for($i = 0; $i < count($stat); $i++) { ?>
							<tr>
								<td><strong><?php echo $stat[$i]["period"]; ?></strong></td>
								<td><?php if(isset($stat[$i]["5"])) echo $stat[$i]["5"]; ?></td>
								<td><?php if(isset($stat[$i]["4"])) echo $stat[$i]["4"]; ?></td>
								<td><?php if(isset($stat[$i]["3"])) echo $stat[$i]["3"]; ?></td>
								<td><?php if(isset($stat[$i]["2"])) echo $stat[$i]["2"]; ?></td>
								<td><?php if(isset($stat[$i]["ach"])) echo $stat[$i]["ach"]; ?></td>
								<td><?php if(isset($stat[$i]["quality"])) echo $stat[$i]["quality"]; ?></td>
							</tr>
					<?php }} ?>
				</tbody>
			</table>
		</div>
	</div>

	    </div>
	</div>
		<select id="period" >
			<?php
			    foreach ($periods as $period) {
							?>
							<option value="<?php echo $period['PERIOD_ID']?>"><?php echo $period['PERIOD_NAME']; ?></option>
									<?php
								}
			?>
		</select>
	<div style="background:white;"><canvas id="myChart"></canvas></div>
	<div id="placeholder"></div>
</div>


<script type="text/javascript">
	$(document).ready(function() {
		document.getElementById('class').value = "<?php echo $this->uri->segment(3);?>";
		document.getElementById('subject').value = "<?php echo $this->uri->segment(4);?>";


		var passes = document.getElementById("myChart").getContext("2d");



	    $('#period').change(function(){
		   // alert("wefef");
		    var base_url = '<?php echo base_url();?>';
		    var period = $(this).find("option:selected").val();
		    var subject = $("#subject").find("option:selected").val();
		    var class_id = $("#class").find("option:selected").val();
		    $.ajax({
			    type: "POST",
			    url: base_url + "api/getpasses/" + period+ "/" + subject + "/" + class_id,
			    cache: false,
			    success: function(data){
				   // $('#answer').html(data);
					var json_obj = JSON.parse(data);
				    var description = new Array();
				    var myvalues1 = new Array();
				    var myvalues2 = new Array();
				    var myvalues3 = new Array();

				    for (var i in json_obj) {
					    description.push(json_obj[i].name);
					    myvalues1.push(json_obj[i].pass[1]);
					    myvalues2.push(json_obj[i].pass[2]);
					    myvalues3.push(json_obj[i].pass[3]);
					}
					var data = {
						labels: description,
						datasets: [
						{
							label: "Пропуски по неуважительной причине",
							fillColor: "#fcf8e3",
							strokeColor: "#8a6d3b",
							data: myvalues1
						},
						{
							label: "Пропуски по уважительной причине",
							fillColor: "#d9edf7",
							strokeColor: "#31708f",
							data: myvalues2
					    },
					    {
						    label: "Пропуски по болезни",
						    fillColor: "#dff0d8",
						    strokeColor: "#3c763d",
						    data: myvalues3
						}
					]};
					var options = {
						animation: false,
						responsive: true,
						maintainAspectRatio: true
					};
					new Chart(passes).Bar(data, options);
					legend(document.getElementById('placeholder'), data);


			    }
			});
		}).change();
	});

</script>