<?php
	function setColor($mark, $tooltip) {
			switch ($mark) {
				case 5: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'"  class="green">'.$mark.'</span>'; break;
				case 4: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'" class="yellow">'.$mark.'</span>'; break;
				case 3: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'" class="blue">'.$mark.'</span>';  break;
				case 2: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'" class="red">'.$mark.'</span>'; break;
			}
	}
?>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading">Успеваемость учащегося <strong><?php if(isset($name)) echo $name;?></strong>
			<form method="post">
				Период
				<select id="period" name="period" onchange="this.form.submit();" >
					<?php
						foreach ($periods as $period) {
								?>
								<option value="<?php echo $period['PERIOD_ID'];?>"><?php echo $period['PERIOD_NAME']; ?></option><?php
								}
						?>
				</select>
			</form>
		</div>
	    <div class="table-responsive">
			<table class="table table-striped table-hover table-bordered numeric">
				<thead>
					<tr>
						<th rowspan="2">#</th>
						<th class="col-md-2" rowspan="2">Предмет</th>
						<th rowspan="2">Оценки</th>
						<th colspan="3" style=" text-align: center;">Пропуски</th>
					</tr>
					<tr>
						<th style="width: 10%; border-bottom-width: 1px;">по болезни</th>
						<th style="width: 10%; border-bottom-width: 1px;">по неуваж.</br>причине</th>
						<th style="width: 10%; border-bottom-width: 1px;">по уваж.</br>причине</th>
					</tr>
				</thead>
				<tbody>
					<?php
						for($i = 0; $i < count($progress); $i++) {
						 ?>
					<tr>
						<td><?php echo $i+1; ?></td>
						<td><?php echo $progress[$i]["subject"]; ?></td>
						<td>
							<?php
								for ($y =0; $y < count($progress[$i]["marks"]); $y++) {
									setColor($progress[$i]["marks"][$y]["mark"], $progress[$i]["marks"][$y]["type"]);
									echo " ";
								}
								?>
						</td>
						<td><?php if(isset($progress[$i]["pass"]['б'])) echo "<strong>".$progress[$i]["pass"]['б']."</strong>"; else echo "<span class='grey'>н/д</span>"; ?></td>
						<td><?php if(isset($progress[$i]["pass"]['н'])) echo "<strong>".$progress[$i]["pass"]['н']."</strong>"; else echo "<span class='grey'>н/д</span>"; ?></td>
						<td><?php if(isset($progress[$i]["pass"]['у'])) echo "<strong>".$progress[$i]["pass"]['у']."</strong>"; else echo "<span class='grey'>н/д</span>"; ?></td>
					</tr>
					<?php
						} ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<script type="text/javascript">
	document.getElementById('period').value = "<?php  echo $this->uri->segment(5);?>";
	$("#period").select2({
		minimumResultsForSearch: Infinity,
		language: "ru"
	});

</script>