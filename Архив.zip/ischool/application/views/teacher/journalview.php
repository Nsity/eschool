<style type="text/css">
	td  {
		cursor: pointer; cursor: hand;
	}
	td:first-child, td:nth-child(2)  {
		cursor: default;
	}
	</style>
<?php
	function setColor($mark, $tooltip) {
		switch ($mark) {
			case 5: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'"  class="green">'.$mark.'</span>'; break;
			case 4: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'" class="yellow">'.$mark.'</span>'; break;
			case 3: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'" class="blue">'.$mark.'</span>';  break;
			case 2: echo '<span data-toggle="tooltip" data-placement="top" title="'.$tooltip.'" class="red">'.$mark.'</span>'; break;
		}
	}
?>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading">Журнал</div>
			<div class="panel-body">
				<div class="row">
					<div class="col-md-6">
				<form method="post">
				Класс</br>
				<select id="class" name="class" onchange="this.form.submit();" style="width: 100%;">
						<?php
							foreach ($classes as $class) {
								if(isset($class['YEAR_ID'])) $year_border = " (".date("Y",strtotime($class['YEAR_START']))." - ".date("Y",strtotime($class['YEAR_FINISH']))." гг.)"; else $year_border = '';
							?>
									<option value="<?php echo $class['CLASS_ID']?>"><?php echo $class['CLASS_NUMBER']." ".$class['CLASS_LETTER'].$year_border; ?></option>
									<?php
								}
						?>
					</select>
			</form>
			<form method="post">
				</br>Предмет</br>
				<select id="subject" name="subject" onchange="this.form.submit();" style="width: 100%;">
						<?php
							foreach ($subjects as $subject) {
									?>
									<option value="<?php echo $subject['SUBJECTS_CLASS_ID']?>"><?php echo $subject['SUBJECT_NAME']; ?></option>
									<?php
								}
						?>
					</select>
			        </form>
			       </div>
			       <div class="col-md-6">
				       <a href="<?php echo base_url();?>teacher/lesson/<?php echo $this->uri->segment(4);?>" role="button" class="btn btn-sample btn-large btn-block"  title="Добавить учебное занятие">Добавить учебное занятие</a>
			<a href="<?php echo base_url();?>teacher/lessons/<?php echo $this->uri->segment(4);  ?>" role="button" class="btn btn-sample btn-large btn-block"  title="Список учебных занятий">Список учебных занятий</a>
			<a href="<?php echo base_url();?>teacher/progress/<?php echo $this->uri->segment(3);?>/<?php echo $this->uri->segment(4); ?>" role="button" class="btn btn-sample btn-large btn-block"  title="Итоговые оценки">Итоговые оценки</a>

			<!--Календарь
			<div id="datepicker" data-date="12/03/2012"></div>
		    <input type="hidden" id="my_hidden_input" />-->
			    </div>
		    </div>
	    </div>
	</div>
    <?php echo $this->pagination->create_links(); ?>
			<div class="panel panel-default">
				<div class="panel-heading">Журнальная страница</div>
				<div class="table-responsive">
					<table class="table table-striped table-hover table-bordered numeric">
						<thead>
							<tr>
								<th>#</th>
								<th>ФИО учащегося</th>
								<?php foreach($lessons as $lesson) { ?>
								<th style="cursor: pointer; cursor: hand;" onclick="document.location.href = '<?php  echo base_url(); ?>teacher/lessonpage/<?php echo $this->uri->segment(4);?>/<?php echo $lesson['LESSON_ID']; ?>'"><?php echo date('d.m', strtotime($lesson['LESSON_DATE']))." ".date('H:i', strtotime($lesson['TIME_START']));?></th>
								<?php }?>
							</tr>
						</thead>
						<tbody>
							<?php
								for($i = 0; $i <count($result); $i++){
									?>
									<tr>
									<td><?php echo $i+1; ?></td>
									<td><?php echo $result[$i]["pupil_name"];?></td>
									<?php if(isset($result[$i]["lessons"])) {
										for($y = 0; $y < count($result[$i]["lessons"]); $y++) { ?>
									<td <?php if(isset($result[$i]["lessons"][$y]["pass"])) {
										switch($result[$i]["lessons"][$y]["pass"]) {
										    case 'н': {
										        ?>class="warning"<?php
										        break;
									        }
										    case 'б': {
											    ?>class="success"<?php
												break;
											}
											case 'у': {
											    ?>class="info"<?php
												break;
										    }
									    } } ?>><?php
										for($z = 0; $z < count($result[$i]["lessons"][$y]["marks"]); $z++) {
											//echo $result[$i]["lessons"][$y]["marks"][$z]["mark"];
											setColor($result[$i]["lessons"][$y]["marks"][$z]["mark"], $result[$i]["lessons"][$y]["marks"][$z]["type"]);
											echo " ";
										}
									?></td>
									<?php }?>
									</tr>
									<?php
								}}
							?>
						</tbody>
					</table>
				</div>
			</div>
			<table style="margin-bottom: 20px;">
				<tr>
					<td><div class="color-swatch brand-success"></div></td>
					<td>Пропуск по болезни</td>
				</tr>
				<tr>
					<td><div class="color-swatch brand-info"></div></td>
					<td>Пропуск по уважительной причине</td>
				</tr>
				<tr>
					<td><div class="color-swatch brand-warning"></div></td>
					<td>Пропуск по неуважительной причине</td>
				</tr>
			</table>

</div>

<script type="text/javascript">
	$(document).ready(function() {
		document.getElementById('class').value = "<?php echo $this->uri->segment(3);?>";
		document.getElementById('subject').value = "<?php echo $this->uri->segment(4);?>";

		$('#datepicker').datepicker({
			format: 'yyyy-mm-dd',
			startDate: "1993-01-01",
		    endDate: "2020-01-01",
		    language: "ru",
		    todayBtn: "linked",
		    calendarWeeks: true,
		    todayHighlight: true
		});
$("#datepicker").on("changeDate", function(event) {
    $("#my_hidden_input").val(
        $("#datepicker").datepicker('getFormattedDate'))
});

		/*$("#class").select2({
			minimumResultsForSearch: Infinity,
			language: "ru"
		});*/
		//$('#class').combobox();

		/*$("#subject").select2({
			minimumResultsForSearch: Infinity,
			language: "ru"
		});*/

		$('table td:not(:first-child, :nth-child(2))').click(function() {
			$('table th').eq($(this).index()).click();
		});

//var period = $('table th').eq($(this).index()/2+1).text();

	});
</script>