<?php
	function hidePassword($password) {
		$s = "";
		for($i = 0; $i < strlen($password); $i++) {
			$s = $s."*";
		}
		echo $s;
	}

	?>

<div class="container">
	<div class="well well-sm"><span class="glyphicon glyphicon-list" aria-hidden="true"></span> Список учителей</div>
    <div class="panel panel-default">
	    <div class="panel-heading">
		     <button type="button" class="btn btn-menu" id="createButton" title="Добавить учителя">
				<span class="glyphicon glyphicon-plus" aria-hidden="true"></span></br>Создать
		    </button>
		    <button href="" type="button" class="btn btn-menu disabled" id="editButton"  title="Редактировать учителя">
				<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></br>Редактировать
		    </button>
		    <button type="button" class="btn btn-menu disabled" id="deleteButton" data-toggle="modal" data-target="#myModal" title="Удалить учителя">
				<span class="glyphicon glyphicon-trash" aria-hidden="true"></span></br>Удалить
		    </button>
	    </div>
	     <div class="panel-body">
     <form method="get">
    <div class="input-group">
      <input type="text" class="form-control" placeholder="Поиск по ФИО и логину" id="search" name="search" value="<?php if(isset($search)) echo $search;?>" >
      <span class="input-group-btn">
        <button class="btn btn-default" type="submit" name="submit" id="searchButton" title="Поиск"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
      </span>
    </div><!-- /input-group -->
	 </form>
  </div>
	    <div class="table-responsive">
		    <table name="timetable" class="table table-striped table-hover table-bordered numeric" data-sort-name="name" data-sort-order="desc">
			    <thead>
				    <tr>
					    <th></th>
					    <th data-sortable="true">ФИО учителя</th> <!--1-->
					    <th>Логин</th> <!--2-->
					    <th>Пароль</th> <!--3-->
					    <th>Статус</th> <!--5-->
					</tr>
				</thead>
				<tbody>
				<?php
					if(is_array($teachers) && count($teachers) ) {
					foreach($teachers as $teacher) {
				?>
					<tr>
					    <td><input type="radio" name="teacher_id" value="<?php echo $teacher['TEACHER_ID'];?>"></td>
						<td ><?php echo $teacher['TEACHER_NAME'];?></td>
						<td><?php echo $teacher['TEACHER_LOGIN'];?></td>
						<td><span data-toggle="tooltip" data-placement="top" title="<?php echo $teacher['TEACHER_PASSWORD']; ?>">
							<?php hidePassword($teacher['TEACHER_PASSWORD']);?></span></td>
						<td><?php if($teacher['TEACHER_STATUS'] == 0) echo "Не активен"; else echo "Активен";?></td>
					</tr>
					<?php }} ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php echo $this->pagination->create_links(); ?>
	<?php
		if(count($teachers) == 0 && isset($search) && $search != "") {
	?>
	<div class="alert alert-info" role="alert">Поиск не дал результатов. Попробуйте другой запрос</div>
	<?php } ?>
</div>


<script type="text/javascript">
	$(document).ready(function() {

		if($(":radio[name=teacher_id]").is(':checked')) {
			$('#editButton').removeClass('disabled');
			$('#deleteButton').removeClass('disabled');
		} else {
			$('#editButton').addClass('disabled');
			$('#deleteButton').addClass('disabled');
		}
		$(":radio[name=teacher_id]").change(function() {
			$('#editButton').removeClass('disabled');
			$('#deleteButton').removeClass('disabled');
		});
	    $('#createButton').click(function() {
			document.location.href = '<?php  echo base_url(); ?>admin/teacher';
		});

		$('#editButton').click(function() {
			var value = $(":radio[name=teacher_id]").filter(":checked").val();
			document.location.href = '<?php  echo base_url(); ?>admin/teacher/' + value;
		});


		$('#buttonDeleteTeacherModal').click(function() {
			var value = $(":radio[name=teacher_id]").filter(":checked").val();
			var base_url = '<?php echo base_url();?>';
			$.ajax({
				type: "POST",
				url: base_url + "table/del/teacher/" + value,
				//data: "id=" + value + "&from=subjects",
				timeout: 30000,
				async: false,
				error: function(xhr) {
					console.log('Ошибка!' + xhr.status + ' ' + xhr.statusText);
				},
				success: function(a) {
					location.reload();
				}
			});
		});

		$("tr:not(:first)").click(function() {
			$(this).children("td").find('input[type=radio]').prop('checked', true).change();
		});

    });
</script>




<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Удаление пользователя</h4>
      </div>
      <div class="modal-body">
        <p>Вы уверены, что хотите удалить этого пользователя?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Отмена</button>
        <button type="button" class="btn btn-sample" id="buttonDeleteTeacherModal">Удалить</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->





