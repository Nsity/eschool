<?php
	function showNewsDate($date) {
			$day = date('d', strtotime($date));
			$mounth = date('m', strtotime($date));
			$year = date('Y', strtotime($date));
			$data = array('01'=>'января','02'=>'февраля','03'=>'марта','04'=>'апреля','05'=>'мая','06'=>'июня',
			'07'=>'июля', '08'=>'августа','09'=>'сентября','10'=>'октября','11'=>'ноября','12'=>'декабря');
			foreach ($data as $key=>$value) {
				if ($key==$mounth) echo "".ltrim($day, '0')." $value $year года";
			}
	}

	function showDate() {
			$day = date('d');
			$mounth = date('m');
			$year = date('Y');
			$data = array('01'=>'января','02'=>'февраля','03'=>'марта','04'=>'апреля','05'=>'мая','06'=>'июня',
			'07'=>'июля', '08'=>'августа','09'=>'сентября','10'=>'октября','11'=>'ноября','12'=>'декабря');
			foreach ($data as $key=>$value) {
				if ($key==$mounth) echo "<b>".ltrim($day, '0')." $value $year года</b>";
			}
	}
	?>

<div class="container">
	<div class="row">
		<div class="col-md-5">
			<!--Расписание на сегодня-->
			<div class="panel panel-default">
				<div class="panel-heading">Расписание на сегодня <?php

							showDate();?></div>
							<div class="table-responsive">
							<table name="timetable" class="table table-striped">
								<thead>
									<tr>
										<th>Время</th>
										<th>Предмет</th>
										<th>Каб.</th>
									</tr>
								</thead>
								<tbody>
								<?php
									for ($k=0; $k < count($timetable); $k++)  {
									?>
								    <tr>
									    <td id="time"><?php echo date("H:i", strtotime($timetable[$k]["start"]));?></td>
									    <td><?php echo $timetable[$k]["name"];?></td>
									    <td id="room"><?php echo $timetable[$k]["room"]; }?></td>
									</tr>
								</tbody>
							</table>
							</div>
							<div class="panel-body">
								<a id="show-timetable" href="<?php echo base_url();?>pupil/timetable" role="button" class="btn btn-sample btn-large btn-block" title="Показать расписание">Смотреть расписание на всю неделю</a>
							</div>
			</div>
			<div class="panel panel-default" id="todaymarks" hidden="true">
			    <div class="panel-heading">Полученные сегодня оценки
			    </div>
				    <div class="panel-body">
						<div style="margin: 20px; margin-top:15px;"><canvas id="myChart"></canvas></div>
							<a href="<?php echo base_url();?>pupil/diary" role="button" class="btn btn-sample btn-large btn-block"  title="Перейти в дневник">Перейти в дневник</a>
					</div>
			</div>
			<div class="panel panel-default" id="todayaverages" hidden="true">
			    <div class="panel-heading">Средний балл по предметами по расписанию на сегодня
			    </div>
				    <div class="panel-body">
						<div><canvas id="myChart1"></canvas></div>
							<a href="<?php echo base_url();?>pupil/statistics" role="button" class="btn btn-sample btn-large btn-block"  title="Перейти в статистику">Перейти в статистику</a>
					</div>
			</div>

		</div>
		<div class="col-md-7">
			<?php
				if(is_array($news) && count($news) ) {
					foreach($news as $row){
						echo "<div class='panel panel-default'>
						<div class='panel-heading'><h4><strong>".$row['NEWS_THEME']."</strong><br/></h4> <div class='newsdate'>";
						echo showNewsDate($row['NEWS_TIME']);
						echo "</div></div>
						<div class='panel-body'>
						<p>".$row['NEWS_TEXT']."</p>
						</div>
						</div>";
					}
				}?>

<?php echo $this->pagination->create_links(); ?>
	</div>
</div>
</div>




<script type="text/javascript">
	$(document).ready(function() {
		var marks = document.getElementById("myChart").getContext("2d");

		var base_url = '<?php echo base_url();?>';

		$.ajax({
			type: "POST",
			url: base_url + "api/todaymarks" ,
			cache: false,
			success: function(data){

				if(JSON.parse(data) == null || JSON.parse(data) == 'error') {
					$('#todaymarks').attr('hidden', true);
				} else {
					$('#todaymarks').attr('hidden', false);
					var data = JSON.parse(data);
					var data = [
					{
						value: data[5],
						color:"#5cb85c",
						label: "Кол-во пятерок"
					},
					{
						value: data[4],
						color: "#ec971f",
						label: "Кол-во четверок"
					},
					{
						value: data[3],
						color: "#337ab7",
						label: "Кол-во троек"
					},
					{
						value: data[2],
						color: "#d9534f",
						label: "Кол-во двоек"
					}
					];
					var options = {
						animation: false,
						responsive: true,
						maintainAspectRatio: true
					};
					new Chart(marks).Pie(data, options);
				}
		    }
		});



		var averages = document.getElementById("myChart1").getContext("2d");
		$.ajax({
			type: "POST",
			url: base_url + "api/todayaverages" ,
			cache: false,
			success: function(data){

				if(JSON.parse(data) == null || JSON.parse(data) == 'error') {
					$('#todayaverages').attr('hidden', true);
				} else {
					$('#todayaverages').attr('hidden', false);
					var data = JSON.parse(data);

					var description = new Array();
					var myvalues = new Array();

					for (i = 1; i <= Object.keys(data).length; i++) {
						//alert(Object.keys(data).length);
						//alert(data[i].subject);
						description.push(data[i].subject);
						myvalues.push(data[i].mark);
						//alert(data[i].mark);
					}
					var step  = 1;
					var max   = 5;
					var start = 0;
					var options = {
						animation: false,
						responsive: true,
						maintainAspectRatio: true,
						scaleOverride: true,
						scaleSteps: Math.ceil((max-start)/step),
						scaleStepWidth: step,
						scaleStartValue: start
					};

					var data = {
						labels: description,
						datasets: [
						{
							label: "Средние баллы",
							fillColor: "rgba(220,220,220,0.5)",
							strokeColor: "rgba(220,220,220,0.8)",
							data: myvalues
						},
					]};

					window.myObjBar = new Chart(averages).Bar(data, options);

					for(i = 0; i < myvalues.length; i++) {
						if (myvalues[i] >= 4.5) {
							myObjBar.datasets[0].bars[i].fillColor = "#5cb85c";
						}
						if (myvalues[i] < 4.5 && myvalues[i] >= 3.5){
							myObjBar.datasets[0].bars[i].fillColor = "#ec971f";
						}
						if(myvalues[i] < 3.5 && myvalues[i] >= 2.5) {
							myObjBar.datasets[0].bars[i].fillColor = "#337ab7";
						}
						if(myvalues[i] < 2.5 && myvalues[i] > 0) {
							myObjBar.datasets[0].bars[i].fillColor = "#d9534f";
						}
						if (myvalues[i] = 0) {
							myObjBar.datasets[0].bars[i].fillColor = "grey";
						}
					}
					myObjBar.update();
				}
		    }
		});






    });
</script>
