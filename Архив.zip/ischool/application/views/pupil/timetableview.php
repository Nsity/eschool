<?php
	 $colors1 = array("#2780e3", "#3fb618", "#9954bb", "#ff18e1", "#ff7518", "#ff0039");
	 $colors = array("#c196c4", "#fab500", "#87ccdb" , "#dbdb01", "#f2a5c9","#feec02");
	 ?>
<div class="container">
		<div class="row">
			<?php
				for ($i = 1; $i <= 6; $i++) {
				?>
			<div class="col-xs-12 col-md-4">
				<div class="panel panel-default">
						<div class="panel-heading" style="background-color: <?php echo $colors1[$i-1]; ?>; border-bottom-color: <?php echo $colors1[$i-1]; ?>;"><?php echo $days[$i-1]?></div>
						<div class="table-responsive">
							<table name="timetable" class="table table-striped">
						<thead>
							<tr>
								<th class=" col-xs-5 col-md-4 col-lg-4">Время</th>
								<th class="col-md-5 col-lg-5">Предмет</th>
								<th class="col-md-2 col-lg-2">Каб.</th>
							</tr>
						</thead>
						<tbody>
							<?php
								for ($k = 0; $k < count($timetable[$i-1]); $k++)  {
								?>
							<tr>
								<td id="time"><?php echo date("H:i", strtotime($timetable[$i-1][$k]["start"])).' - '
									.date("H:i",strtotime($timetable[$i-1][$k]["finish"]));?></td>
								<td><?php echo $timetable[$i-1][$k]["name"];?></td>
								<td id="room"><?php echo $timetable[$i-1][$k]["room"]; }?></td>
							</tr>
						</tbody>
					</table>
						</div>
				</div>
</div>
			<?php if ($i==3) {?>
				<div class="clearfix visible-md visible-xs visible-lg"></div>
				<?php } ?>
					<?php }?>
		</div>
</div>