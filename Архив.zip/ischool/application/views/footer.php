<!--Footer-->
	<footer class="footer">
      <div class="container">
        <p class="text-muted">Copyright © 2015 Nsity. All rights reserved.</p>
      </div>
    </footer>
</body>
</html>
    <!--Footer-->