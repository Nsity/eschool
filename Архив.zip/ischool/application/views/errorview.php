<div class="container">
	<?php if(isset($error)) {?>
	<div class="alert alert-danger" role="alert"><?php echo $error; ?></div>
	<?php }?>
</div>