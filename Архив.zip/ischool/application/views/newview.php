<!DOCTYPE html>
<html lang = "ru">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Сайт электронного дневника учащегося">
    <meta name="keywords" content="diary, school, pupil, дневник, школа, информационная система">
    <meta name="author" content="Федорова А.П.">
    <title> <?
	if(isset($title)) echo $title." | Электронный дневник учащегося";
	else echo "Электронный дневник учащегося";
	?></title>
    <link rel="shortcut icon" href="<?php echo base_url();?>images/school-new.png">
    <title>Электронный дневник учащегося</title>
    <!--Bootstrap-->

    <script src="<?php echo base_url();?>bootstrap/js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <link rel="stylesheet" href="<?php echo base_url();?>bootstrap/css/bootstrap.min.css">
	<link href="<?php echo base_url();?>css/navbar.css" rel="stylesheet">
	<link href="<?php echo base_url();?>css/style-new.css" rel="stylesheet">
	<link href="<?php echo base_url();?>css/font-awesome.min.css" rel="stylesheet">

  </head>
  <body>
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Электронный дневник</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="#">Главная</a></li>
        <li><a href="#">Расписание</a></li>
        <li><a href="#">Дневник</a></li>
        <li><a href="#">Статистика</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Link</a></li>
      </ul>
    </div>
  </div>
</nav>
<section class="title-section">
	<h1 class="title-header">About Our Company</h1>
</section>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="blog_grid">
				<h2 class="post_title">Праздник к нам приходит ewfwefwfwefewfewfwefewfw</h2>
				<ul class="links">
					<li><i class="fa fa-calendar"></i> December 03, 2014</li>
					<li><i class="fa fa-user"></i> Cris</li>
				</ul>
				<p>Компиляция производится командой makeotf -r. Эта команда за один вызов обрабатывает одно начертание в текущей папке. Вместо того, чтобы ходить по папкам в консоли и каждый раз запускать команду вручную, создадим скрипт для PowerShell, который в пакетном режиме скомпилирует все необходимые файлы. За основу возьмем из корневой папки шрифта скрипт build.sh и сохраним новый файл под именем build.ps1 там же.</p>
				<a href="#" class="blog_btn">Read more</a>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading">Расписание на сегодня <b>22 мая 2015 года</b></div>
							<div class="table-responsive">
							<table name="timetable" class="table table-striped">
								<thead>
									<tr>
										<th>Время</th>
										<th>Предмет</th>
										<th>Каб.</th>
									</tr>
								</thead>
								<tbody>
																    <tr>
									    <td id="time">08:30</td>
									    <td>География</td>
									    <td id="room">208								    </td></tr><tr>
									    <td id="time">09:30</td>
									    <td>Английский язык</td>
									    <td id="room">210								    </td></tr><tr>
									    <td id="time">10:25</td>
									    <td>Физика</td>
									    <td id="room">304								    </td></tr><tr>
									    <td id="time">11:25</td>
									    <td>Информатика</td>
									    <td id="room">310								    </td></tr><tr>
									    <td id="time">12:30</td>
									    <td>Алгебра</td>
									    <td id="room">								    </td></tr><tr>
									    <td id="time">13:25</td>
									    <td>Биология</td>
									    <td id="room">212</td>
									</tr>
								</tbody>
							</table>
							</div>
							<div class="panel-body">
								<a id="show-timetable" href="http://192.168.0.19:8888/ischool/pupil/timetable" role="button" class="btn btn-sample btn-large btn-block" title="Показать расписание">Смотреть расписание на всю неделю</a>
							</div>
			</div>
		</div>
	</div>
</div>