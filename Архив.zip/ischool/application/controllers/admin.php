<?php
	class Admin extends CI_Controller {

		public function __construct() {
            parent::__construct();
            $this->load->model('adminmodel', 'admin');
            $this->load->model('tablemodel', 'table');
        }

		function _remap($method, $params = array())
		{
			$login = $this->session->userdata('login');
			$role = $this->session->userdata('role');

			if(isset($login) && isset($role) && $role == "2") {
				switch($method) {
					case 'teachers': {
						$data['title'] = "Список учителей";
						break;
					}
					case 'news': {
						$data['title'] = "Список новостей";
						break;
					}
					case 'types': {
						$data['title'] = "Список типов оценок";
						break;
					}
					case 'classes': {
						$data['title'] = "Список классов";
						break;
					}
					case 'rooms': {
						$data['title'] = "Список кабинетов";
						break;
					}
					case 'subjects': {
						$data['title'] = "Список общих предметов";
						break;
					}
					case 'years': {
						$data['title'] = "Список учебных годов";
						break;
					}
					case 'teacher': {
						$data['title'] = "Учитель";
						break;
					}
					case 'newsitem': {
						$data['title'] = "Новость";
						break;
					}
					case 'subject': {
						$data['title'] = "Общий предмет";
						break;
					}
					case 'room': {
						$data['title'] = "Кабинет";
						break;
					}
					case 'classitem': {
						$data['title'] = "Класс";
						break;
					}
					case 'type': {
						$data['title'] = "Тип оценки";
						break;
					}
					case 'year': {
						$data['title'] = "Учебный год";
						break;
					}
				}

				$data['role'] = $role;
				$data['mainlogin'] = $login;
				$this->load->view('header', $data);
				if (method_exists($this, $method))
				{
					call_user_func_array(array($this, $method), $params);
				}
				else {
					redirect(base_url()."admin/teachers");
				}
				$this->load->view('footer');
			}
			else {
				redirect('auth/logout');
			}
		}

		function teachers($offset = 1) {
			$search = "";
			if(isset($_GET['submit'])) {
				if(isset($_GET['search'])) {
					$search = urldecode($_GET['search']);
					$data['search'] = $search;
					if ($search == "") {
						redirect(base_url()."admin/teachers");
					} else redirect(base_url()."admin/teachers?search=".$search);
				}
			}
			if(isset($_GET['search'])) {
				$search = $_GET['search'];
				$data['search'] = $search;
			}
			$num = 10;
			$config['total_rows'] = $this->admin->totalTeachers($search);
			$config['base_url'] = base_url()."admin/teachers";
			$config['per_page'] = $num;


			if (count($_GET) > 0)  { $config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
			}

			$this->pagination->initialize($config);

			$query = $this->admin->getTeachers($num, $offset * $num - $num, $search);
			$data['teachers'] = null;
			if($query) {
				$data['teachers'] =  $query;
			}

			$this->load->view("admin/teachersview", $data);
		}

		function classes($offset = 1) {
			$search = "";
			if(isset($_GET['submit'])) {
				if(isset($_GET['search'])) {
					$search = urldecode($_GET['search']);
					$data['search'] = $search;
					if ($search == "") {
						redirect(base_url()."admin/classes");
					} else redirect(base_url()."admin/classes?search=".$search);
				}
			}
			if(isset($_GET['search'])) {
				$search = $_GET['search'];
				$data['search'] = $search;
			}
			$num = 10;

			$config['total_rows'] = $this->admin->totalClasses($search);
			$config['base_url'] = base_url()."admin/classes";
			$config['per_page'] = $num;


			if (count($_GET) > 0)  { $config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
			}

			$this->pagination->initialize($config);
			$query = $this->admin->getClasses($num, $offset * $num - $num, $search);
			$data['classes'] = null;
			if($query) {
				$data['classes'] =  $query;
			}
			$this->load->view("admin/classesview", $data);
		}


		function subjects($offset = 1) {
			$search = "";
			if(isset($_GET['submit'])) {
				if(isset($_GET['search'])) {
					$search = urldecode($_GET['search']);
					$data['search'] = $search;
					if ($search == "") {
						redirect(base_url()."admin/subjects");
					} else redirect(base_url()."admin/subjects?search=".$search);
				}
			}
			if(isset($_GET['search'])) {
				$search = $_GET['search'];
				$data['search'] = $search;
			}

			$num = 10;

			$config['total_rows'] = $this->admin->totalSubjects($search);
			$config['base_url'] = base_url()."admin/subjects";
			$config['per_page'] = $num;

			if (count($_GET) > 0)  { $config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
			}


			$this->pagination->initialize($config);
			$query = $this->admin->getSubjects($num, $offset * $num - $num, $search);
			$data['subjects'] = null;
			if($query) {
				$data['subjects'] =  $query;
			}
			$this->load->view("admin/subjectsview", $data);
		}


		function subject($id = null) {
			if(isset($_POST['save'])) {
				$name = $_POST['inputSubject'];
				if(isset($id)) {
					$this->table->updateSubject($name, $id);
				} else {
					$this->table->addSubject($name);
				}
				redirect(base_url()."admin/subjects");
			} else {
			if(isset($id)) {
				$subject = $this->admin->getSubjectById($id);
				if(isset($subject)) {
					$data['subject'] = $subject['SUBJECT_NAME'];
					$data['id'] = $subject['SUBJECT_ID'];
					$data['title'] = 'Редактирование общего предмета';
					$this->load->view("blankview/blanksubjectview", $data);

				} else {
					//ошибка
					$data['error'] = "Такого общего предмета не существует. Вернитесь обратно";
					$this->load->view("errorview", $data);
				}
			} else {
				$data['title'] = 'Добавление нового общего предмета';
				$this->load->view("blankview/blanksubjectview", $data);

			}
			}
		}


		function type($id = null) {
			if(isset($_POST['save'])) {
				$name = $_POST['inputType'];
				if(isset($id)) {
					$this->table->updateType($name, $id);
				} else {
					$this->table->addType($name);
				}
				redirect(base_url()."admin/types");
			} else {
				if(isset($id)) {
					$type = $this->admin->getTypeById($id);
					if(isset($type)) {
						$data['type'] = $type['TYPE_NAME'];
						$data['id'] = $type['TYPE_ID'];
						$data['title'] = 'Редактирование типа оценки';
						$this->load->view("blankview/blanktypeview", $data);
					} else {
						//ошибка
						$data['error'] = "Такого типа оценки не существует. Вернитесь обратно";
						$this->load->view("errorview", $data);
					}
				} else {
					$data['title'] = 'Добавление нового типа оценки';
					$this->load->view("blankview/blanktypeview", $data);
				}
			}
		}

		function room($id = null) {
			if(isset($_POST['save'])) {
				$name = $_POST['inputRoom'];
				if(isset($id)) {
					$this->table->updateRoom($name, $id);
				} else {
					$this->table->addRoom($name);
				}
				redirect(base_url()."admin/rooms");
			} else {
			if(isset($id)) {
				$room = $this->admin->getRoomById($id);
				if(isset($room)) {
					$data['room'] = $room['ROOM_NAME'];
					$data['id'] = $room['ROOM_ID'];
					$data['title'] = 'Редактирование кабинета';
					$this->load->view("blankview/blankroomview", $data);
				} else {
					//ошибка
					$data['error'] = "Такого кабинета не существует. Вернитесь обратно";
					$this->load->view("errorview", $data);
				}
			} else {
				$data['title'] = 'Добавление нового кабинета';
				$this->load->view("blankview/blankroomview", $data);
			}
			}
		}



		function rooms($offset = 1) {
			$search = "";
			if(isset($_GET['submit'])) {
				if(isset($_GET['search'])) {
					$search = urldecode($_GET['search']);
					$data['search'] = $search;
					if ($search == "") {
						redirect(base_url()."admin/rooms");
					} else redirect(base_url()."admin/rooms?search=".$search);
				}
			}
			if(isset($_GET['search'])) {
				$search = $_GET['search'];
				$data['search'] = $search;
			}
			// Переменная хранит число сообщений выводимых на станице
			$num = 10;

			$config['total_rows'] = $this->admin->totalRooms($search);
			$config['base_url'] = base_url()."admin/rooms";
			$config['per_page'] = $num;

			if (count($_GET) > 0)  { $config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
			}

			$this->pagination->initialize($config);

			$query = $this->admin->getRooms($num, $offset * $num - $num, $search);
			$data['rooms'] = null;
			if($query) {
				$data['rooms'] =  $query;
			}
			$this->load->view("admin/roomsview", $data);
		}



		function types($offset = 1) {
			$search = "";
			if(isset($_GET['submit'])) {
				if(isset($_GET['search'])) {
					$search = urldecode($_GET['search']);
					$data['search'] = $search;
					if ($search == "") {
						redirect(base_url()."admin/types");
					} else redirect(base_url()."admin/types?search=".$search);
				}
			}
			if(isset($_GET['search'])) {
				$search = $_GET['search'];
				$data['search'] = $search;
			}

			// Переменная хранит число сообщений выводимых на станице
			$num = 10;

			$config['total_rows'] = $this->admin->totalTypes($search);
			$config['base_url'] = base_url()."admin/types";
			$config['per_page'] = $num;

			if (count($_GET) > 0)  { $config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
			}

			$this->pagination->initialize($config);

			$query = $this->admin->getTypes($num, $offset * $num - $num, $search);
			$data['types'] = null;
			if($query) {
				$data['types'] =  $query;
			}
			$this->load->view("admin/typesview", $data);
		}


		function news($offset = 1) {
			$search = "";
			if(isset($_GET['submit'])) {
				if(isset($_GET['search'])) {
					$search = urldecode($_GET['search']);
					$data['search'] = $search;
					if ($search == "") {
						redirect(base_url()."admin/news");
					} else redirect(base_url()."admin/news?search=".$search);
				}
			}
			if(isset($_GET['search'])) {
				$search = $_GET['search'];
				$data['search'] = $search;
			}

			// Переменная хранит число сообщений выводимых на станице
			$num = 10;

			$id = $this->session->userdata('id');

			$config['total_rows'] = $this->admin->totalNews($id, $search);
			$config['base_url'] = base_url()."admin/news";
			$config['per_page'] = $num;

			if (count($_GET) > 0)  { $config['suffix'] = '?' . http_build_query($_GET, '', "&");
				$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
			}

			$this->pagination->initialize($config);

			$query = $this->admin->getNews($num, $offset * $num - $num, $id, $search);
			$data['news'] = null;
			if($query) {
				$data['news'] =  $query;
			}
			$this->load->view("admin/newsview", $data);
		}


		function newsitem($id = null) {
			if(isset($_POST['save'])) {
				$admin = $this->session->userdata('id');
				$theme = $_POST['inputTheme'];
				$text = $_POST['inputText'];
				$date = $_POST['inputDate'];
				if(isset($id)) {
					$this->table->updateNews($id, $theme, $date, $text, $admin);
				} else {
					$this->table->addNews($theme, $date, $text, $admin);
				}
				redirect(base_url()."admin/news");
			} else {
				if(isset($id)) {
					$admin = $this->session->userdata('id');
					$news = $this->admin->getNewsById($id, $admin);
					if(isset($news)) {
					    $data['date'] = $news['NEWS_TIME'];
					    $data['id'] = $news['NEWS_ID'];
					    $data['text'] = $news['NEWS_TEXT'];
					    $data['theme'] = $news['NEWS_THEME'];
					    $data['title'] = 'Редактирование новости';
					    $this->load->view("blankview/blanknewsview", $data);
				    } else {
					   //ошибка
					    $data['error'] = "Такой новости не существует. Вернитесь обратно";
					    $this->load->view("errorview", $data);
				}
	            } else {
		            $data['title'] = 'Добавление новой новости';
				    $this->load->view("blankview/blanknewsview", $data);
			    }
			}
		}


		function classitem($id = null) {
			$data['years'] = $this->admin->getYears();
			$data['teachers'] = $this->admin->getAllTeachers();
			$data['classes'] = $this->admin->getAllClasses();
			if(isset($_POST['save'])) {
				$number = $_POST['inputNumber'];
				$letter = $_POST['inputLetter'];
				$year = $_POST['inputYear'];
				$status = $_POST['inputStatus'];
				$teacher = $_POST['inputTeacher'];
				$previous = $_POST['inputPrevious'];
				if(isset($id)) {
					$this->table->updateClass($id, $number, $letter, $year, $status, $teacher, $previous);
				} else {
					$this->table->addClass($number, $letter, $year, $status, $teacher, $previous);
				}
				redirect(base_url()."admin/classes");
			} else {
			if(isset($id)) {
				$classitem = $this->admin->getClassById($id);
				if(isset($classitem)) {
					$data['id'] = $classitem['CLASS_ID'];
					$data['number'] = $classitem['CLASS_NUMBER'];
					$data['letter'] = $classitem['CLASS_LETTER'];
					$data['status'] = $classitem['CLASS_STATUS'];
					$data['previous'] = $classitem['CLASS_PREVIOUS'];
					$data['year_id'] = $classitem['YEAR_ID'];
					$data['teacher_id'] = $classitem['TEACHER_ID'];

					$data['status_allow'] = false;
					foreach( $this->admin->getAllClasses() as $class) {
						if($class['CLASS_PREVIOUS'] == $classitem['CLASS_ID']) {
							$data['status_allow'] = true;
						}
					}

					$data['title'] = 'Редактирование класса';
					$this->load->view("blankview/blankclassview", $data);
				} else {
					//ошибка
					$data['error'] = "Такого класса не существует. Вернитесь обратно";
					$this->load->view("errorview", $data);
				}
			} else {
				$data['title'] = 'Добавление нового класса';
				$this->load->view("blankview/blankclassview", $data);
			}
			}

		}


		function teacher($id = null) {
			if(isset($_POST['save'])) {
				$name = $_POST['inputName'];
				$password = $_POST['inputPassword'];
				$login = $_POST['inputLogin'];
				$status = $_POST['inputStatus'];
				if(isset($id)) {
					$this->table->updateTeacher($id, $name, $password, $login, $status, md5($password));
				} else {
					$this->table->addTeacher($name, $password, $login, $status, md5($password));
				}
				redirect(base_url()."admin/teachers");
			} else {
			if(isset($id)) {
				$teacher = $this->admin->getTeacherById($id);
				if(isset($teacher)) {
					$data['id'] = $teacher['TEACHER_ID'];
					$data['name'] = $teacher['TEACHER_NAME'];
					$data['login'] = $teacher['TEACHER_LOGIN'];
					$data['password'] = $teacher['TEACHER_PASSWORD'];
					$data['status'] = $teacher['TEACHER_STATUS'];
					$data['title'] = 'Редактирование учителя';
					$this->load->view("blankview/blankteacherview", $data);
				} else {
					//ошибка
					$data['error'] = "Такого учителя не существует. Вернитесь обратно";
					$this->load->view("errorview", $data);
				}
			} else {
				$data['title'] = 'Добавление нового учителя';
				$this->load->view("blankview/blankteacherview", $data);
			}
			}
		}



		function years($offset = 1) {
			// Переменная хранит число сообщений выводимых на станице
			$num = 10;

			$config['total_rows'] = $this->admin->totalYears();
			$config['base_url'] = base_url()."admin/periods";
			$config['per_page'] = $num;

			$this->pagination->initialize($config);

			$query = $this->admin->getYearsLimit($num, $offset * $num - $num);
			$data['periods'] = null;
			if($query) {
				$data['periods'] =  $query;
			}
			$this->load->view("admin/yearsview", $data);
		}


		function year($id = null) {
			if(isset($_POST['save'])) {
			    $year_start = $_POST['inputYearStart'];
			    $year_finish = $_POST['inputYearFinish'];

			    $first_start = $_POST['inputFirstStart'];
			    $first_finish = $_POST['inputFirstFinish'];

			    $second_start = $_POST['inputSecondStart'];
			    $second_finish = $_POST['inputSecondFinish'];

			    $third_start = $_POST['inputThirdStart'];
			    $third_finish = $_POST['inputThirdFinish'];

			    $forth_start = $_POST['inputForthStart'];
			    $forth_finish = $_POST['inputForthFinish'];
				if(isset($id)) {
					$this->table->updateYearAndPeriods($id, $year_start, $year_finish,
			$first_start, $first_finish, $second_start, $second_finish, $third_start,$third_finish, $forth_start, $forth_finish);
				} else {
					$this->table->addYearAndPeriods($year_start, $year_finish,
			$first_start, $first_finish, $second_start, $second_finish, $third_start,$third_finish, $forth_start, $forth_finish);
				}
				redirect(base_url()."admin/years");
			} else {
			if(isset($id)) {
				$year = $this->admin->getYearById($id);
				if(isset($year)) {
					$data['info'] = $year;
					$data['id'] = $year["id"];
					$data['title'] = 'Редактирование учебного года';
					$this->load->view("blankview/blankyearview", $data);
				} else {
					//ошибка
					$data['error'] = "Такого учебного года не существует. Вернитесь обратно";
					$this->load->view("errorview", $data);
				}
			} else {
				$data['title'] = 'Добавление нового учебного года';
				$this->load->view("blankview/blankyearview", $data);
			}
			}
		}

	}
?>