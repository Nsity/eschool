<?php
	class Blog extends CI_Controller {
		function index() {
			$this->load->view("newview");
			$this->load->view("footer");
		}
	}
?>